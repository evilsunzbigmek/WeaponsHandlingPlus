# Changelog

## 1.0.0

First public release.

- Dynamic arm strength: firm while guarding, fluid while swinging, eased between the two from hand speed.
- Damping scales with stiffness, keeping the vanilla spring/damper balance (smooth, no jitter or stalled chops).
- Separate two-handed profile (detected from the game's off-hand grip state), which fixes two-handed swing stutter.
- Stronger strong-of-the-blade: higher arm force cap while guarding.
- Stronger weapon grip (Grip Rate x3, off-hand / alternate grips x2).
- Minimum off-hand grip for hafted weapons (halberds etc.).
- Pain and injury preserved: every change multiplies the game's current value and follows its resets.
- F7 full on/off with an on-screen message, F8 re-apply, F9 status report.
- Optional hit log for debugging (off by default).
