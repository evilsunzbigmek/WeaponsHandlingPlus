-- WeaponsHandling+ config
-- Edit values, then in the UE4SS console use "Restart All Mods" (or restart the game).

return {
    Keys = {
        Toggle = Key.F7,  -- full on/off: off = vanilla arms, grip AND weapon weight (rebuilds weapons)
        Apply  = Key.F8,  -- re-apply now (forgets what was already tuned)
        Dump   = Key.F9,  -- print status to UE4SS.log
    },

    StartEnabled = true,
    ShowToast    = true,  -- small on-screen "WeaponsHandling+ ON/OFF" message when pressing F7
    ToastSeconds = 2.5,
    AffectNPCs   = true,   -- false = only your own character

    -- How often to check the arm variables. The game may rewrite them (pain, injury,
    -- stamina); each time it does, we re-multiply the game's NEW value, so pain/injury
    -- still scale the arms down. Lower = the boost is present more of the time.
    ArmIntervalMs    = 50,   -- 50 ms so the hold/swing blend reacts quickly
    WeaponIntervalMs = 2000,

    ---------------------------------------------------------------------------
    -- ARMS: multipliers on the game's own variables on Willie_BP_C.
    -- 1.0 = leave alone. Values the dump found (defaults, uninjured):
    --   Arm R/L Tonus 1.0, Orientation Strength 1000, Angular Strength 100,
    --   Max Angular Force 5000, Muscle Power 35
    ---------------------------------------------------------------------------
    Arms = {
        -- DYNAMIC (2026-10-27): firm when holding, fluid when swinging. When Enabled, this
        -- drives Orientation Strength, Angular Strength and Max Angular Force; their
        -- entries in Multipliers below are ignored.
        Dynamic = {
            Enabled   = true,
            HandBones = { "hand_r", "hand_l" },
            RefBone   = "pelvis",   -- hand speed is measured relative to this (ignores walking)
            -- Hand speed (cm/s) below SlowSpeed = full hold, above FastSpeed = full swing.
            -- F9 prints the peak hand speed: set FastSpeed to roughly half your swing peak.
            -- 2026-10-27 dump: swing peaks ~1400 cm/s (player), 800-1000 (NPCs). 150/600 was too
            -- low: guard adjustments and the jolt of an enemy hitting your blade counted as a
            -- "swing" and softened the arm right when it had to resist.
            SlowSpeed = 400,
            FastSpeed = 900,
            RiseTime  = 0.12,  -- seconds to ease into swing mode. Slower than a knock jolt
                               -- (<0.1 s) so blocks stay firm, quick enough for real swings.
            FallTime  = 0.35,  -- seconds to ease back to hold (slow, so impacts don't lock up)
            -- Raised after "knocked away too easily, slightly floppy" (weapons are also 1.5x
            -- heavier now via the rebuild). Was Hold 1.6/1.3, Swing 1.1/1.0.
            -- MaxForce raised 1.6 -> 1.9 for blocking (force cap = how big a blow the arm can
            -- absorb; stiffness left alone so motion stays smooth).
            -- MaxForce 2.3 makes the strong of the blade feel stronger.
            -- Hits near the hands push the arms (resisted by this force
            -- cap); hits near the tip spin the weapon in the grip (Grip Rate, left at 3).
            Hold  = { Orientation = 1.8, MaxForce = 2.3 },  -- guard: resists being knocked away
            Swing = { Orientation = 1.25, MaxForce = 1.1 }, -- swing: a bit above vanilla, fluid
            -- Two-handed grip (game var "L Hand In Offhand Attached" = true): both arms are
            -- tied through the handle, so stiff arms fight each other -> stuttering swings.
            -- Lower stiffness, keep high force so the shared grip still resists slaps.
            TwoHanded = {
                Enabled = true,
                Var   = "L Hand In Offhand Attached",
                -- MaxForce lowered from 1.6/1.1: arm torque cap (5000 x 1.6 = 8000) got close
                -- to the off-hand grip strength (OffhandStr 9900), so the arms could pull the
                -- off hand along the handle -> slip/catch stutter. Slap resistance now comes
                -- mainly from Grip Rate.
                -- 1.2 -> 1.4 for blocking. 5000 x 1.4 = 7000 vs off-hand grip 9900 x 2 = 19800,
                -- so the arms still can't drag the off hand (stutter fix holds).
                -- 1.4 -> 1.8 (strong of the blade / haft, 2026-10-31). 5000 x 1.8 = 9000: swords'
                -- off-hand grip is 19800, hafted weapons get the LiveVarFloors minimum 12000.
                Hold  = { Orientation = 1.35, MaxForce = 1.8 },
                Swing = { Orientation = 1.05, MaxForce = 1.0 },
            },
            -- Angular Strength (damping) = sqrt(Orientation multiplier) x DampingTrim.
            -- Keeps the vanilla spring/damper balance. Trim <1 = looser/whippier, >1 = heavier.
            DampingFollowsStiffness = true,
            DampingTrim = 1.0,
        },
        Multipliers = {
            -- 2026-10-27: x2/x2/x2 stalled overhead chops; x1.6/x1.2/x1.5 + Tonus x1.3 still
            -- stiffened up mid-swing. The game changes Tonus 100-250x/min (likely relaxing
            -- the arms during swings), so Tonus is now left to the game.
            ["Arm R Tonus"]          = 1.0,
            ["Arm L Tonus"]          = 1.0,
            ["Orientation Strength"] = 1.5,  -- main stiffness: pull toward the target pose (holding)
            -- x1.15 force cap made arms lock up slightly when hitting enemies. With the cap at
            -- vanilla, the x1.5 stiffness still helps at light loads, but on impact the arm
            -- yields like vanilla. If it still locks: Orientation 1.3.
            ["Angular Strength"]     = 1.0,  -- damping: brakes fast arm motion. Too high = chops stall
            ["Max Angular Force"]    = 1.0,  -- cap on muscle torque; >1 = arms fight impacts/swings
            ["Muscle Power"]         = 1.0,  -- untested; try 1.2-1.5 if arms feel weak
        },
        -- Safety cap: a value is never pushed above (first value seen) x multiplier,
        -- so it can't run away if the game blends from our value.
        CapToFirstSeen = true,
    },

    ---------------------------------------------------------------------------
    -- WEAPONS: mass mode. Multiplies weapon mass; rotational inertia scales with it, so the
    -- weapon carries more momentum and resists wrist flicks. Heavier weapons also hit harder
    -- and load the arms more. (Direct inertia-only scaling is broken in this game; removed.)
    ---------------------------------------------------------------------------
    Weapons = {
        -- OFF: tested 2026-10-27 02:21. SetMassScale / SetMassOverrideInKg give unpredictable
        -- results on these welded modular weapons (asked x1.5, got x2.49 or x2.00) and the
        -- revert didn't reliably restore mass. Don't enable.
        Enabled      = false,
        ClassName    = "ModularWeaponBP_C",
        MassScale    = 1.5,   -- must be >1.1 or <0.9 to do anything. Try 1.3-2.0.
        -- Game-side weapon variables on ModularWeaponBP_C, multiplied like the arm vars.
        -- Safe: only the game's own value changes, F7 restores it. Defaults seen: Mass Adjust
        -- Scale (Temp) 1.0; Custom Mass Scale Head 1.125 / Guard 0.84 / Grip 0.25 / Pommel 0.675.
        -- Raising Head (tip) mass = more lever. F9 shows whether real mass/inertia changed.
        -- Setting these live did nothing (game reads them only when building a weapon).
        -- So: when a NEW weapon spawns (match setup), multiply them, wait 0.5 s, then call
        -- the weapon's "ReSpawn Weapon Parts Event" to rebuild it. Weapons that already exist
        -- when the mod loads/reloads are never rebuilt. F9 + log show mass before -> after.
        GameVarsEnabled = true,
        GameVars = {
            -- 1.0 = vanilla weights (vanilla weights are realistic, e.g.
            -- 3.2 kg for the largest two-hander; x1.5 made them heavier than real swords).
            -- At 1.0 nothing is rebuilt. The rebuild machinery still works if raised again.
            ["Mass Adjust Scale (Temp)"] = 1.0,
            ["Custom Mass Scale Head"]   = 1.0,  -- try 1.3 if Mass Adjust has no effect
        },
        -- Actor names containing any of these are left alone (FindAllOf also returns
        -- subclasses: shields, fists, named axes...). Add "Shield" to skip shields.
        -- Live weapon variables, re-applied every 0.5 s like the arm vars (F7 restores).
        -- "Grip Rate" (default 1) looks like the hand's grip strength on the weapon: the
        -- safe stand-in for v2.0's "sword can't be slapped out of line" feel. Experimental:
        -- F9 shows whether the game keeps resetting it. Set 1.0 to turn off.
        LiveVars = {
            ["Grip Rate"] = 3.0,     -- confirmed: swords harder to slap away (was 2.0; raised for blocking)
            -- Off-hand / alternate-grip hold on the handle (default 9900). Raised so the
            -- stronger arms can't pull the hands along the handle (two-handed stutter).
            -- May only take effect the next time the hand grabs the handle.
            -- was 1.5; raised so two-handed blocks hold and the off hand stays well above
            -- the arm force (keeps the two-handed stutter fix intact).
            ["OffhandStr"]   = 2.0,
            ["AltGrip1_Str"] = 2.0,
            ["AltGrip2_Str"] = 2.0,
        },
        -- Minimums for the live vars (after the multiplier). Hafted weapons have a weak vanilla
        -- off-hand grip (halberd OffhandStr 3000, x2 = 6000), below the two-handed arm force
        -- (9000), so the arms could drag the off hand along the haft -> weak base + stutter.
        -- 12000 keeps the off hand above the arms. Swords (19800) are unaffected. Values of 0
        -- (shields: no off-hand grip) are left at 0. Delete a line to drop its minimum.
        LiveVarFloors = {
            ["OffhandStr"]   = 12000,
            ["AltGrip1_Str"] = 12000,
            ["AltGrip2_Str"] = 12000,
        },
        Exclude      = { "Fists", "Feet" },  -- kick/punch "weapons" are subclasses too
    },

    -- Hit recorder: every hit your held weapon lands (edge/tip alignment, cut/stab rate,
    -- damage, bone, what was struck, mod on/off). F9 prints hits since the last F9.
    HitLog = {
        Enabled = false,
        Keep    = 25,     -- max hits kept between F9 presses
        LogLive = false,   -- also write each hit to UE4SS.log as it happens
    },

    -- F9 also lists every game variable on up to 3 weapon types (long output)
    DumpWeaponVars = false,      -- full list was read on 2026-10-27; set true to see it again
    DumpWeaponFunctions = false, -- weapon Blueprint functions about mass/grip/build (read 2026-10-27)

    -- Extra variables printed by F9 (not modified)
    WatchVars = { "Pain Arm R", "Pain Arm L", "Pain R Arm Alpha", "Pain L Arm Alpha",
                  "Arm_R Health", "Arm_L Health", "R Arm Extra Tonus", "L Arm Extra Tonus",
                  "Equipment Weight To Strength Upper",
                  "L Hand In Offhand Attached", "L Offhand Searching Grip",
                  "R_GripType_Current", "L_GripType_Current" },
}
