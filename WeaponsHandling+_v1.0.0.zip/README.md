# WeaponsHandling+

A [UE4SS](https://github.com/UE4SS-RE/RE-UE4SS) Lua mod for **Half Sword** that makes arms firmer and weapons handle like real levers, without touching the game's pain and injury system.

## What it does

- **Firm guard, fluid swings.** Arm strength adapts to what you're doing. While you hold a guard, your arms are stiffer and resist being knocked aside. When you swing, they loosen up, so cuts flow and don't stall.
- **Two-handed grip support.** Two-handed weapons get their own arm profile, so both arms stop fighting each other through the handle (no swing stutter).
- **Weapons act like levers.** Blows near your hands (the strong of the blade, or the haft) are hard to push aside. Blows near the tip still swing the weapon around, as they would in real life.
- **Better blocking.** Stronger grip on the weapon, so it isn't slapped out of your hands as easily.
- **Polearm fix.** Hafted weapons (halberds etc.) get a minimum off-hand grip, so the off hand doesn't slide along the haft under arm force.
- **Pain and injury still work.** The mod multiplies the game's own values, so an injured or tired arm is still weaker.
- **Vanilla weapon weights.** Weights are left at their realistic vanilla values.
- **Works on NPCs too** (can be turned off), so fights stay fair.

## Requirements

- Half Sword (UE5 version)
- [UE4SS](https://github.com/UE4SS-RE/RE-UE4SS) **v3.0.1** or newer, installed in `Half Sword\HalfswordUE5\Binaries\Win64\`

## Install

1. Install UE4SS for Half Sword if you haven't yet.
2. Copy the `WeaponsHandling+` folder into:
   ```
   Half Sword\HalfswordUE5\Binaries\Win64\ue4ss\Mods\
   ```
3. Make sure the mod is enabled. The folder contains an `enabled.txt`, which turns it on. Alternatively, add this line to `ue4ss\Mods\mods.txt`:
   ```
   WeaponsHandling+ : 1
   ```
4. Start the game.

## Controls

| Key | Action |
|-----|--------|
| **F7** | Turn the mod on or off (an on-screen message confirms it) |
| **F8** | Re-apply all settings |
| **F9** | Write a status report to `ue4ss\UE4SS.log` |

## Configuration

All settings are in `WeaponsHandling+\Scripts\config.lua`, with comments explaining each one. After editing, restart the game (or use "Restart All Mods" in the UE4SS console).

Main knobs:

| Setting | What it changes |
|---------|-----------------|
| `Arms.Dynamic.Hold` | Arm stiffness and strength while guarding (one-handed) |
| `Arms.Dynamic.Swing` | Arm stiffness and strength while swinging (one-handed) |
| `Arms.Dynamic.TwoHanded` | The same two profiles for two-handed grips |
| `Arms.Dynamic.SlowSpeed` / `FastSpeed` | Hand speeds (cm/s) that count as "guarding" and "swinging" |
| `Weapons.LiveVars["Grip Rate"]` | How firmly the hand holds the weapon (higher = harder to slap away, tips stiffer too) |
| `Weapons.LiveVarFloors` | Minimum off-hand grip strength (polearm fix) |
| `AffectNPCs` | `false` = only your character gets the changes |
| `HitLog.Enabled` | Debug: log every hit your weapon lands (alignment, cut/stab rate, armor surface, location) |

Multipliers are relative to vanilla: `1.0` = unchanged.

## Notes

- Weapon weight changes (`Weapons.GameVars`) are off by default (`1.0`). If you raise them, weapons are rebuilt when they spawn, and F7 restores them.
- `Weapons.Enabled` (the old engine mass mode) is unreliable in this game. Leave it `false`.
- Armor: the mod doesn't change how armor protects. Testing with the hit log showed plate and mail stop cuts identically with the mod on and off.

## Troubleshooting

Press **F9** and look at the end of `ue4ss\UE4SS.log` for lines starting with `[WeaponsHandling+]`. Any line containing `failed:` is an error. Please include those lines when reporting a problem.

## License

[MIT](LICENSE): free for anyone to use, modify and share, as long as the license notice is kept.
