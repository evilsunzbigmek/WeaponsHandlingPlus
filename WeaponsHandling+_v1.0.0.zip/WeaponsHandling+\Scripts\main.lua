-- WeaponsHandling+ v1.0.0 for Half Sword (UE4SS Lua mod)
-- Multiplies the game's own arm-muscle variables on Willie_BP_C and scales weapon inertia.
-- All tuning lives in config.lua. F7 on/off, F8 re-apply, F9 status dump.

local Cfg = require("config")
local TAG = "[WeaponsHandling+] "
local function log(msg) print(TAG .. tostring(msg) .. "\n") end

local NAME_None = FName("None")
local enabled = Cfg.StartEnabled ~= false
local pawns = {}    -- pawn address -> { obj, isPlayer, vars = { name -> state } }
local weaponVars = {}  -- weapon address -> { obj, name, vars = { name -> state }, mass0 }
local weapons = {}  -- weapon address -> state
local startTime = os.time()

---------------------------------------------------------------------------
-- helpers
---------------------------------------------------------------------------
local function valid(o)
    if o == nil then return false end
    local ok, r = pcall(function() return o:IsValid() end)
    return ok and r
end

local function safe(label, fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok then log(label .. " failed: " .. tostring(err)) end
    return ok, err
end

local function nameOf(o)
    local ok, n = pcall(function() return o:GetFName():ToString() end)
    return ok and n or "?"
end

local function classNameOf(o)
    local ok, n = pcall(function() return o:GetClass():GetFName():ToString() end)
    return ok and n or "?"
end

local function addr(o)
    local ok, a = pcall(function() return o:GetAddress() end)
    return ok and a or nil
end

local function readNum(o, name)
    local ok, v = pcall(function() return o[name] end)
    if ok and type(v) == "number" then return v end
    return nil
end

local function writeNum(o, name, v)
    return pcall(function() o[name] = v end)
end

local function vec(v)
    local ok, s = pcall(function() return { X = v.X, Y = v.Y, Z = v.Z } end)
    return ok and s or nil
end

local function vecStr(v)
    if not v then return "(?)" end
    return string.format("(%.4g, %.4g, %.4g)", v.X, v.Y, v.Z)
end

local function getPlayerPawn()
    local pc = FindFirstOf("PlayerController")
    if not valid(pc) then return nil end
    local ok, p = pcall(function() return pc.Pawn end)
    if ok and valid(p) then return p end
    return nil
end

---------------------------------------------------------------------------
-- ARMS: multiply the game's variables, re-multiply whenever the game resets them
---------------------------------------------------------------------------
local function tuneVar(pawn, st, name, mult, floor)
    local v = readNum(pawn, name)
    if v == nil then st.missing = true; return end
    local s = st.vars[name]
    if s == nil then
        s = { base = v, first = v, written = nil, resets = 0 }
        st.vars[name] = s
    elseif s.written ~= nil then
        local tol = 1e-4 * math.max(1, math.abs(s.written))
        if math.abs(v - s.written) <= tol then
            if s.mult == mult then return end  -- still our value, same multiplier
        else
            s.base = v      -- the game wrote a new value (pain, injury, state change)
            s.resets = s.resets + 1
        end
    else
        s.base = v          -- was disabled; take the game's current value
    end
    s.mult = mult
    local target = s.base * mult
    if Cfg.Arms.CapToFirstSeen and mult > 1 and s.first > 0 then
        target = math.min(target, s.first * mult)
    end
    -- Optional minimum (weapon grips). Only for values the game uses (base > 0): a shield's
    -- OffhandStr of 0 means "no off-hand grip" and must stay 0.
    if floor and s.base > 0 then target = math.max(target, floor) end
    if writeNum(pawn, name, target) then
        s.written = readNum(pawn, name) or target
    end
end

local function restorePawn(st)
    if not valid(st.obj) then return end
    for name, s in pairs(st.vars) do
        if s.written ~= nil then
            local cur = readNum(st.obj, name)
            -- only restore if it is still our value; otherwise the game already owns it
            if cur and math.abs(cur - s.written) <= 1e-4 * math.max(1, math.abs(s.written)) then
                writeNum(st.obj, name, s.base)
            end
            s.written = nil
        end
    end
end

---------------------------------------------------------------------------
-- DYNAMIC ARMS: firm when holding (guard, binds), fluid when swinging.
-- Hand speed relative to the pelvis tells us which: slow = hold, fast = swing. The blend
-- rises quickly into a swing and eases back slowly afterwards, so nothing snaps.
-- Damping (Angular Strength) follows sqrt(stiffness multiplier): that keeps the
-- spring/damper ratio the same as vanilla, which is what makes motion smooth instead of
-- springy (too little damping) or stalling (too much).
---------------------------------------------------------------------------
local DYN_NAMES = { ["Orientation Strength"] = true, ["Angular Strength"] = true, ["Max Angular Force"] = true }
local boneFNames = {}
local function boneF(n)
    local f = boneFNames[n]
    if not f then f = FName(n); boneFNames[n] = f end
    return f
end

local function handSpeed(pawn, st)
    local D = Cfg.Arms.Dynamic
    local mesh = st.mesh
    if not valid(mesh) then
        pcall(function() mesh = pawn.Mesh end)
        st.mesh = mesh
    end
    if not valid(mesh) then return nil end
    local ref = nil
    pcall(function() ref = vec(mesh:GetPhysicsLinearVelocity(boneF(D.RefBone))) end)
    if not ref then return nil end
    local best = 0
    for _, b in ipairs(D.HandBones) do
        local v = nil
        pcall(function() v = vec(mesh:GetPhysicsLinearVelocity(boneF(b))) end)
        if v then
            local dx, dy, dz = v.X - ref.X, v.Y - ref.Y, v.Z - ref.Z
            local s = math.sqrt(dx * dx + dy * dy + dz * dz)
            if s > best then best = s end
        end
    end
    return best
end

local function lerp(a, b, t) return a + (b - a) * t end

local function dynamicMults(pawn, st)
    local D = Cfg.Arms.Dynamic
    local speed = handSpeed(pawn, st)
    st.speed = speed
    if speed and speed > (st.peakSpeed or 0) then st.peakSpeed = speed end
    local target = 0
    if speed then
        target = (speed - D.SlowSpeed) / math.max(1, D.FastSpeed - D.SlowSpeed)
        target = math.max(0, math.min(1, target))
    end
    local dt = Cfg.ArmIntervalMs / 1000
    local cur = st.swing or 0
    local tau = (target > cur) and D.RiseTime or D.FallTime
    local alpha = 1 - math.exp(-dt / math.max(0.001, tau))
    cur = cur + (target - cur) * alpha
    st.swing = cur
    -- Two-handed: both hands are tied together through the weapon, so stiff arms pulling
    -- toward their own poses fight each other through the handle (stutter). Use a gentler
    -- profile; the two arms share the load, so the blade is still held firmly.
    local hold, swing = D.Hold, D.Swing
    local twoH = false
    if D.TwoHanded and D.TwoHanded.Enabled ~= false then
        pcall(function() twoH = pawn[D.TwoHanded.Var or "L Hand In Offhand Attached"] == true end)
        if twoH then hold, swing = D.TwoHanded.Hold, D.TwoHanded.Swing end
    end
    st.twoHanded = twoH
    st.ticks = (st.ticks or 0) + 1
    if twoH then st.twoHandTicks = (st.twoHandTicks or 0) + 1 end
    local o = lerp(hold.Orientation, swing.Orientation, cur)
    local f = lerp(hold.MaxForce, swing.MaxForce, cur)
    local d = (D.DampingFollowsStiffness ~= false) and math.sqrt(o) or 1.0
    -- round to 0.01 so we don't rewrite the variables for meaningless changes
    local function r(x) return math.floor(x * 100 + 0.5) / 100 end
    return { ["Orientation Strength"] = r(o), ["Angular Strength"] = r(d * (D.DampingTrim or 1.0)),
             ["Max Angular Force"] = r(f) }
end

local function applyArms()
    local list = FindAllOf("Willie_BP_C")
    if not list then return end
    local player = getPlayerPawn()
    local pa = player and addr(player)
    local seen = {}
    for _, pawn in ipairs(list) do
        if valid(pawn) then
            local a = addr(pawn)
            local isPlayer = (a ~= nil and a == pa)
            if a and (Cfg.AffectNPCs or isPlayer) then
                seen[a] = true
                local st = pawns[a]
                if st == nil then
                    st = { obj = pawn, vars = {}, isPlayer = isPlayer, name = nameOf(pawn) }
                    pawns[a] = st
                end
                st.obj, st.isPlayer = pawn, isPlayer
                local dyn = Cfg.Arms.Dynamic and Cfg.Arms.Dynamic.Enabled
                if dyn then
                    for name, mult in pairs(dynamicMults(pawn, st)) do
                        tuneVar(pawn, st, name, mult)
                    end
                end
                for name, mult in pairs(Cfg.Arms.Multipliers) do
                    if mult ~= 1.0 and not (dyn and DYN_NAMES[name]) then
                        tuneVar(pawn, st, name, mult)
                    end
                end
            end
        end
    end
    for a in pairs(pawns) do if not seen[a] then pawns[a] = nil end end
end

---------------------------------------------------------------------------
-- WEAPONS: MassScale mode. A heavier weapon gets more mass AND proportionally more
-- rotational inertia. Uses engine functions only (SetMassScale, SetMassOverrideInKg,
-- GetMass, GetInertiaTensor). The old BodyInstance.InertiaTensorScale field write is
-- gone: UE4SS reads/writes it wrong in this game (zeroed forged-weapon inertia).
---------------------------------------------------------------------------
local function inertiaOf(comp)
    local ok, v = pcall(function() return comp:GetInertiaTensor(NAME_None) end)
    return ok and vec(v) or nil
end

local function massOf(comp)
    local ok, m = pcall(function() return comp:GetMass() end)
    return ok and m or nil
end

local function massScaleOf(comp)
    local ok, m = pcall(function() return comp:GetMassScale(NAME_None) end)
    return (ok and type(m) == "number" and m > 0) and m or 1.0
end

local function near(a, b)
    return b > 0 and math.abs(a / b - 1) <= 0.1
end

local function ratioOf(cur, base)
    if not (cur and base) or base.X <= 0 or base.Y <= 0 or base.Z <= 0 then return nil end
    return { X = cur.X / base.X, Y = cur.Y / base.Y, Z = cur.Z / base.Z }
end

local function isExcluded(name)
    -- Blueprint templates (not real weapons in the world). Touching them changes every
    -- weapon later spawned from them.
    if string.find(name, "GEN_VARIABLE", 1, true) or string.find(name, "Default__", 1, true) then
        return true
    end
    for _, word in ipairs(Cfg.Weapons.Exclude or {}) do
        if string.find(name, word, 1, true) then return true end
    end
    return false
end

local function weaponBody(actor)
    local ok, root = pcall(function() return actor.RootComponent end)
    if ok and valid(root) then return root end
    ok, root = pcall(function() return actor:K2_GetRootComponent() end)
    if ok and valid(root) then return root end
    return nil
end

local function revertWeapon(w)
    if not valid(w.comp) then return end
    if w.method == "MassOverride" and w.baseMass then
        pcall(function() w.comp:SetMassOverrideInKg(NAME_None, w.baseMass, true) end)
    end
    pcall(function() w.comp:SetMassScale(NAME_None, w.origMassScale or 1.0) end)
end

-- Per-weapon state machine, advanced once per weapon pass (every WeaponIntervalMs):
--   nil      -> record baseline mass, SetMassScale(orig x scale)        -> "verify"
--   "verify" -> mass ~= baseline x scale ? "ok"
--               else try SetMassOverrideInKg once (body may use a kg override)
--               else revert -> "failed"
--   "ok"     -> if the game rebuilt the body back to baseline, apply again
local function tuneWeapon(actor)
    local a = addr(actor)
    if not a then return end
    local w = weapons[a]
    if w == nil then
        w = { obj = actor, name = nameOf(actor), resets = 0 }
        weapons[a] = w
    end
    if w.phase == "failed" or w.phase == "excluded" then return end
    if isExcluded(w.name) then w.phase = "excluded"; w.status = "excluded"; return end

    local comp = weaponBody(actor)
    if not comp then w.status = "no root component"; return end
    if w.comp and addr(w.comp) ~= addr(comp) then w.phase = nil end  -- body replaced
    w.comp = comp
    w.compDesc = classNameOf(comp) .. " " .. nameOf(comp)
    local sim = false
    pcall(function() sim = comp:IsSimulatingPhysics(NAME_None) end)
    if not sim then w.status = "root not simulating physics (yet)"; return end

    local scale = Cfg.Weapons.MassScale
    local mass = massOf(comp)
    if not mass or mass <= 0 then w.status = "can't read mass"; return end
    w.massNow = mass
    w.inertiaNow = inertiaOf(comp)

    if w.phase == nil then
        w.baseMass = mass
        w.baseInertia = w.inertiaNow
        w.origMassScale = massScaleOf(comp)
        w.method = "MassScale"
        pcall(function() comp:SetMassScale(NAME_None, w.origMassScale * scale) end)
        w.phase, w.status = "verify", "applied, verifying"
        return
    end

    local ratio = mass / w.baseMass
    if w.phase == "verify" then
        if near(ratio, scale) then
            w.phase, w.status = "ok", "OK (" .. w.method .. ")"
        elseif w.method == "MassScale" then
            -- MassScale was ignored (body probably has a kg override): set the kg directly
            w.method = "MassOverride"
            pcall(function() comp:SetMassScale(NAME_None, w.origMassScale) end)
            pcall(function() comp:SetMassOverrideInKg(NAME_None, w.baseMass * scale, true) end)
        else
            revertWeapon(w)
            w.phase = "failed"
            w.status = string.format("FAILED, reverted (mass ratio %.2f, wanted %.2f)", ratio, scale)
            log(w.name .. " " .. w.status)
        end
    elseif w.phase == "ok" then
        if near(ratio, 1.0) then
            w.resets = w.resets + 1  -- game rebuilt the body; apply again
            w.phase = nil
        end
    end
end

local function restoreWeapon(w)
    if w.phase == "ok" or w.phase == "verify" then revertWeapon(w) end
    if w.phase ~= "excluded" then w.phase = nil end
end

local function applyWeapons()
    if not Cfg.Weapons.Enabled then return end
    local s = Cfg.Weapons.MassScale
    if type(s) ~= "number" or s <= 0 or near(s, 1.0) then return end  -- needs >1.1 or <0.9
    local list = FindAllOf(Cfg.Weapons.ClassName) or {}
    local seen = {}
    for _, actor in ipairs(list) do
        if valid(actor) then
            local a = addr(actor)
            if a then seen[a] = true end
            safe("Weapon " .. nameOf(actor), tuneWeapon, actor)
        end
    end
    for a in pairs(weapons) do if not seen[a] then weapons[a] = nil end end
end

---------------------------------------------------------------------------
-- ON / OFF
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- WEAPON REBUILD: the game only reads its weapon mass variables ("Mass Adjust Scale
-- (Temp)", "Custom Mass Scale Head"...) when it builds a weapon. So when a NEW weapon
-- appears (match setup), we multiply those variables and call the weapon's own
-- "ReSpawn Weapon Parts Event" so the game rebuilds it with them. Each weapon is rebuilt
-- once. Weapons that already exist when the mod (re)loads are skipped, so a reload or
-- F8 mid-fight never rebuilds a weapon in someone's hands.
---------------------------------------------------------------------------
local weaponFirstScan = true
local REBUILD_FN = "ReSpawn Weapon Parts Event"

local function bodyStats(actor)
    local body = weaponBody(actor)
    if not body then return nil, nil end
    return massOf(body), inertiaOf(body)
end

local scanCount = 0

-- Step 1 (first sight): multiply the vars now, so if the game hasn't built the weapon
-- yet its own build already uses them. Rebuild is scheduled ~0.5 s later.
local function prepareWeapon(actor, st)
    st.mass0, st.inertia0 = bodyStats(actor)
    local changed, wanted = 0, 0
    for name, mult in pairs(Cfg.Weapons.GameVars or {}) do
        if mult ~= 1.0 then
            wanted = wanted + 1
            local v = readNum(actor, name)
            -- Only multiply a game default (1.0). Anything else was already adjusted (by us,
            -- or inherited from a template we touched), so multiplying again would stack.
            if v ~= nil and math.abs(v - 1.0) < 1e-3 and writeNum(actor, name, v * mult) then
                st.vars[name] = { base = v, first = v, written = v * mult, resets = 0 }
                changed = changed + 1
            end
        end
    end
    if changed == 0 then
        st.status = (wanted == 0) and "vanilla weight (no rebuild configured)"
            or "weight setting not at default 1.0; not rebuilt"
        return
    end
    st.status = "waiting to rebuild"
    st.rebuildAt = scanCount + math.max(1, math.floor(500 / Cfg.ArmIntervalMs))
end

-- Step 2: ask the game to rebuild the weapon parts with the new values.
local function rebuildWeapon(actor, st)
    local held = false
    pcall(function() held = actor["Is Held"] == true end)
    st.heldAtRebuild = held
    local ok, err = pcall(function()
        local fn = actor[REBUILD_FN]
        fn(actor)
    end)
    if ok then
        st.status = "rebuilt"
        st.checkAt = os.time() + 2  -- measure the new mass a couple of seconds later
    else
        st.status = "rebuild call failed: " .. tostring(err)
        log(st.name .. " " .. st.status)
    end
end

local function applyWeaponVars()
    if not Cfg.Weapons.GameVars or Cfg.Weapons.GameVarsEnabled == false then return end
    scanCount = scanCount + 1
    local list = FindAllOf(Cfg.Weapons.ClassName) or {}
    local seen = {}
    for _, actor in ipairs(list) do
        if valid(actor) then
            local a = addr(actor)
            if a then
                seen[a] = true
                local st = weaponVars[a]
                if st == nil then
                    local nm = nameOf(actor)
                    st = { obj = actor, vars = {}, name = nm }
                    weaponVars[a] = st
                    if isExcluded(nm) then
                        st.status = "excluded"
                    elseif weaponFirstScan then
                        st.status = "existed when mod loaded; not rebuilt"
                    else
                        prepareWeapon(actor, st)
                    end
                elseif st.status ~= "excluded" and Cfg.Weapons.LiveVars
                        and scanCount % 10 == 0 and not st.rebuildAt then
                    -- live weapon vars (e.g. Grip Rate): re-applied when the game resets them
                    local floors = Cfg.Weapons.LiveVarFloors or {}
                    for name, mult in pairs(Cfg.Weapons.LiveVars) do
                        if mult ~= 1.0 or floors[name] then tuneVar(actor, st, name, mult, floors[name]) end
                    end
                end
                if st.rebuildAt and scanCount >= st.rebuildAt then
                    st.rebuildAt = nil
                    rebuildWeapon(actor, st)
                elseif st.checkAt and os.time() >= st.checkAt then
                    st.checkAt = nil
                    st.mass1, st.inertia1 = bodyStats(actor)
                    log(string.format("Rebuilt %s (held=%s): mass %s -> %s kg, inertia %s -> %s",
                        st.name, tostring(st.heldAtRebuild),
                        st.mass0 and string.format("%.2f", st.mass0) or "?",
                        st.mass1 and string.format("%.2f", st.mass1) or "?",
                        vecStr(st.inertia0), vecStr(st.inertia1)))
                end
            end
        end
    end
    weaponFirstScan = false
    for a in pairs(weaponVars) do if not seen[a] then weaponVars[a] = nil end end
end

local function disableAll()
    for _, st in pairs(pawns) do restorePawn(st) end
    for _, st in pairs(weaponVars) do restorePawn(st) end
    for _, w in pairs(weapons) do restoreWeapon(w) end
end

local function forgetAll()
    disableAll()
    pawns, weapons, weaponVars = {}, {}, {}
    weaponFirstScan = true  -- never rebuild weapons that already exist (may be held)
end

---------------------------------------------------------------------------
-- HIT RECORDER: watches the weapons the player holds. When the game updates a weapon's
-- "Last Hit Power", it just registered a hit, so we copy the game's own hit variables
-- (edge/tip alignment, cut/stab rate, damage, bone, what was struck). Runs with the mod
-- on AND off, and records which, so vanilla vs modded hits can be compared with F7.
---------------------------------------------------------------------------
local hitLog = {}
local hitWeapons = {}   -- weapons currently held by the player
local lastHitPower = {} -- weapon address -> last seen "Last Hit Power"
local hitScan = 0

local HIT_NUM = { "Last Hit Power", "Raw Damage", "Edge Alignment", "Tip Alignment",
                  "Edge Sharpness", "Tip Sharpness", "Cutting Rate", "Stab Rate",
                  "Hit Surface", "Dismemberment Level Sharp", "Dismemberment Level Blunt",
                  "Last Impulse Length" }
local HIT_BOOL = { "Piercing", "Stab?", "Sliding" }

local function fmtNum(v)
    if v == nil then return "?" end
    return string.format("%.3g", v)
end

local function formatHit(h)
    local parts = {}
    for _, n in ipairs(HIT_NUM) do table.insert(parts, n .. "=" .. fmtNum(h[n])) end
    for _, n in ipairs(HIT_BOOL) do
        if h[n] ~= nil then table.insert(parts, n .. "=" .. tostring(h[n])) end
    end
    -- "Hit Actor" reads empty in this game; the struck component's owner names the target.
    local extra = {}
    if h.fromHand then
        if h.weaponLen then
            table.insert(extra, string.format("on your weapon: %.0f cm from your hand (%.0f%% of length %.0f)",
                h.fromHand, 100 * h.fromHand / h.weaponLen, h.weaponLen))
        else
            table.insert(extra, string.format("on your weapon: %.0f cm from your hand", h.fromHand))
        end
    end
    if h.spin then table.insert(extra, string.format("weapon spin after %.0f deg/s", h.spin)) end
    if h.armor then table.insert(extra, "armor at point: " .. h.armor) end
    if h.speed then
        -- read up to 50 ms after contact, so it's the speed after the impact slowed it
        table.insert(extra, string.format("blade speed after contact %.0f cm/s", h.speed))
    end
    if h.burst and h.burst > 1 then
        table.insert(extra, string.format("BURST x%d on this bone within 0.15 s (contact jitter)", h.burst))
    end
    return string.format("HIT %s [mod %s] %s%s, bone=%s, struck=%s%s\n      %s\n      where: %s%s",
        h.t, h.mod and "ON" or "OFF", h.weapon, h.actor and (" -> " .. h.actor) or "", h.bone or "?",
        h.comp or "?", h.compOwner and (" (owner " .. h.compOwner .. ")") or "",
        table.concat(parts, "  "), h.where or "contact point not read",
        (#extra > 0) and ("\n      " .. table.concat(extra, "  |  ")) or "")
end

-- Joints a blade can slip into between armor plates. A bone's origin is its joint with
-- its parent bone (upperarm origin = shoulder, lowerarm = elbow, hand = wrist, ...).
local HIT_JOINTS = {
    { "Head", "head/neck top" }, { "neck_01", "neck" }, { "neck_02", "neck" },
    { "clavicle_l", "collarbone L" }, { "clavicle_r", "collarbone R" },
    { "upperarm_l", "shoulder/armpit L" }, { "upperarm_r", "shoulder/armpit R" },
    { "lowerarm_l", "elbow L" }, { "lowerarm_r", "elbow R" },
    { "hand_l", "wrist L" }, { "hand_r", "wrist R" },
    { "thigh_l", "hip/groin L" }, { "thigh_r", "hip/groin R" },
    { "calf_l", "knee L" }, { "calf_r", "knee R" },
    { "foot_l", "ankle L" }, { "foot_r", "ankle R" },
}

local function dist(a, b)
    local dx, dy, dz = a.X - b.X, a.Y - b.Y, a.Z - b.Z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

-- Where on the body the weapon touched: distance to the nearest joints, and how far along
-- the struck bone (0% = its joint end, 100% = the next joint).
local function hitLocation(w, h)
    local p = nil
    pcall(function() p = vec(w["Impact Point"]) end)
    if not p or (p.X == 0 and p.Y == 0 and p.Z == 0) then
        h.where = "contact point unreadable (Impact Point = " .. vecStr(p) .. ")"
        return
    end
    h.point = p
    local mesh = nil
    pcall(function()
        local c = w["Hit Comp"]
        if valid(c) and classNameOf(c):find("SkeletalMesh") then mesh = c end
    end)
    if not mesh then h.where = "not a body (point " .. vecStr(p) .. ")"; return end

    local function boneLoc(name)
        local ok, idx = pcall(function() return mesh:GetBoneIndex(boneF(name)) end)
        if not ok or type(idx) ~= "number" or idx < 0 then return nil end
        local l = nil
        pcall(function() l = vec(mesh:GetSocketLocation(boneF(name))) end)
        return l
    end

    local near = {}
    for _, j in ipairs(HIT_JOINTS) do
        local l = boneLoc(j[1])
        if l then table.insert(near, { label = j[2], d = dist(p, l) }) end
    end
    table.sort(near, function(a, b) return a.d < b.d end)
    local s = {}
    for i = 1, math.min(2, #near) do
        table.insert(s, string.format("%.0f cm from %s", near[i].d, near[i].label))
    end
    local txt = (#s > 0) and table.concat(s, ", ") or "no joints found"

    -- Position along the struck bone, if it has a known child joint
    local CHILD = { upperarm_l = "lowerarm_l", upperarm_r = "lowerarm_r",
                    lowerarm_l = "hand_l", lowerarm_r = "hand_r",
                    thigh_l = "calf_l", thigh_r = "calf_r", calf_l = "foot_l", calf_r = "foot_r" }
    local b = h.bone
    if b and CHILD[b] then
        local a, c = boneLoc(b), boneLoc(CHILD[b])
        if a and c then
            local len = dist(a, c)
            if len > 1 then
                local t = ((p.X - a.X) * (c.X - a.X) + (p.Y - a.Y) * (c.Y - a.Y) + (p.Z - a.Z) * (c.Z - a.Z)) / (len * len)
                txt = txt .. string.format("; %.0f%% along %s", t * 100, b)
            end
        end
    end
    -- Sanity: the hit bone should be close to the contact point
    if b then
        local bl = boneLoc(b)
        if bl and dist(p, bl) > 80 then txt = txt .. " (point far from hit bone: maybe stale)" end
    end
    h.where = txt
    h.point = p
    -- Armor check disabled: 2026-10-27 test showed armor pieces have no physics collision
    -- (only the internal "BoneCore" mesh answered), so distances were meaningless.
    -- Protection is decided by the game per contact ("Hit Surface"), not by armor collision.
    -- safe("Armor check", armorCheck, mesh, p, h)
end

-- Armor pieces worn by a character: mesh components owned by it, or by actors attached to
-- it, other than its body mesh. Cached per character for 10 s (FindAllOf is slow-ish).
local armorCache = {}
local armorListed = {}

local function armorPieces(victim, body)
    local va = addr(victim)
    local c = armorCache[va]
    if c and os.time() - c.at < 10 then return c.list end
    local list = {}
    local ba = addr(body)
    for _, cls in ipairs({ "SkeletalMeshComponent", "StaticMeshComponent" }) do
        for _, comp in ipairs(FindAllOf(cls) or {}) do
            if valid(comp) and addr(comp) ~= ba then
                local o, mine = nil, false
                pcall(function() o = comp:GetOwner() end)
                if valid(o) then
                    if addr(o) == va then mine = true
                    else
                        local par = nil
                        pcall(function() par = o:GetAttachParentActor() end)
                        if valid(par) and addr(par) == va then mine = true end
                    end
                end
                -- skip weapons/shields: they're attached to hands, not armor
                if mine and not classNameOf(o):find("Weapon") and not classNameOf(o):find("Shield") then
                    table.insert(list, { comp = comp, name = nameOf(comp), owner = nameOf(o) })
                end
            end
        end
    end
    armorCache[va] = { at = os.time(), list = list }
    -- Print the armor layout once per character so the structure can be checked
    if not armorListed[va] then
        armorListed[va] = true
        log(string.format("Armor pieces on %s: %d", nameOf(victim), #list))
        for _, a in ipairs(list) do
            local coll = "?"
            pcall(function() coll = tostring(a.comp:IsCollisionEnabled()) end)
            log(string.format("    %s %s (owner %s) collision=%s",
                classNameOf(a.comp), a.name, a.owner, coll))
        end
    end
    return list
end

-- Is there an armor piece at the contact point? Uses the piece's collision shape if it has
-- one (distance 0 = point is inside the armor), else its bounding box.
function armorCheck(body, p, h)
    local victim = nil
    pcall(function() victim = body:GetOwner() end)
    if not valid(victim) then return end
    local best, bestName, how = nil, nil, nil
    for _, a in ipairs(armorPieces(victim, body)) do
        if valid(a.comp) then
            local d = nil
            pcall(function()
                local out = {}
                local r = a.comp:GetClosestPointOnCollision(p, out, FName("None"))
                if type(r) == "number" and r >= 0 then d = r end
            end)
            local kind = "collision"
            if d == nil then
                -- no collision on the piece: use its bounding box
                pcall(function()
                    local bb = a.comp.Bounds
                    local bo, be = vec(bb.Origin), vec(bb.BoxExtent)
                    if bo and be and (be.X > 0 or be.Y > 0 or be.Z > 0) then
                        local dx = math.max(0, math.abs(p.X - bo.X) - be.X)
                        local dy = math.max(0, math.abs(p.Y - bo.Y) - be.Y)
                        local dz = math.max(0, math.abs(p.Z - bo.Z) - be.Z)
                        d = math.sqrt(dx * dx + dy * dy + dz * dz)
                        kind = "box"
                    end
                end)
            end
            if d and (best == nil or d < best) then best, bestName, how = d, a.name, kind end
        end
    end
    if best == nil then
        h.armor = "no armor pieces measurable"
    elseif best < 0.5 then
        h.armor = string.format("INSIDE %s (%s)", bestName, how)
    else
        h.armor = string.format("%.1f cm from %s (%s)", best, bestName, how)
    end
end

local function snapshotHit(w)
    local h = { t = os.date("%H:%M:%S"), mod = enabled, weapon = nameOf(w) }
    for _, n in ipairs(HIT_NUM) do h[n] = readNum(w, n) end
    for _, n in ipairs(HIT_BOOL) do
        local ok, v = pcall(function() return w[n] end)
        if ok and type(v) == "boolean" then h[n] = v end
    end
    pcall(function() h.bone = w["Hit Bone Name"]:ToString() end)
    pcall(function()
        local c = w["Hit Comp"]
        if valid(c) then
            h.comp = classNameOf(c) .. " " .. nameOf(c)
            local o = c:GetOwner()
            if valid(o) then h.compOwner = classNameOf(o) .. " " .. nameOf(o) end
        end
    end)
    pcall(function()
        local a = w["Hit Actor"]
        if valid(a) then h.actor = classNameOf(a) .. " " .. nameOf(a) end
    end)
    safe("Hit location", hitLocation, w, h)
    -- Where on YOUR weapon the contact was: distance from your sword hand, as a share of the
    -- weapon's length (0% = hand, 100% = tip). Plus how fast the weapon is spinning right
    -- after: a big spin on a block = the blade got knocked around.
    pcall(function()
        local player = getPlayerPawn()
        local hand = nil
        if player and h.point then
            hand = vec(player.Mesh:GetSocketLocation(boneF("hand_r")))
        end
        if hand then
            h.fromHand = dist(h.point, hand)
            local len = readNum(w, "Weapon Length")
            if len and len > 1 then h.weaponLen = len end
        end
    end)
    pcall(function()
        local av = vec(w.RootComponent:GetPhysicsAngularVelocityInDegrees(FName("None")))
        if av then h.spin = math.sqrt(av.X * av.X + av.Y * av.Y + av.Z * av.Z) end
    end)
    -- Blade speed at contact: at 60 fps the blade moves speed/60 cm per frame. If that is
    -- more than armor thickness (~0.2-0.5 cm plate, a few cm overall), a fast blade can
    -- tunnel through the collision between frames = a physics glitch, not a gap.
    pcall(function()
        local v = vec(w.RootComponent:GetPhysicsLinearVelocity(FName("None")))
        if v then h.speed = math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z) end
    end)
    -- Burst: several hits on the same bone within ~0.15 s = contact jitter (blade
    -- vibrating against or through a surface), a sign of janky collision.
    h.tick = hitScan
    h.burst = 1
    for i = #hitLog, 1, -1 do
        local o = hitLog[i]
        if o.tick and h.tick - o.tick <= 3 then
            if o.bone == h.bone then h.burst = h.burst + 1 end
        else break end
    end
    table.insert(hitLog, h)
    local keep = (Cfg.HitLog and Cfg.HitLog.Keep) or 25
    while #hitLog > keep do table.remove(hitLog, 1) end
    if Cfg.HitLog and Cfg.HitLog.LogLive then log(formatHit(h)) end
end

local function trackHits()
    if not (Cfg.HitLog and Cfg.HitLog.Enabled) then return end
    hitScan = hitScan + 1
    if hitScan % 10 == 1 then
        -- refresh the list of weapons the player is holding (every ~0.5 s)
        hitWeapons = {}
        local player = getPlayerPawn()
        local pa = player and addr(player)
        if pa then
            for _, w in ipairs(FindAllOf(Cfg.Weapons.ClassName) or {}) do
                if valid(w) and not string.find(nameOf(w), "GEN_VARIABLE", 1, true) then
                    local held, parent = false, nil
                    pcall(function() held = w["Is Held"] == true end)
                    pcall(function() parent = w["Parent Actor"] end)
                    if held and valid(parent) and addr(parent) == pa then
                        table.insert(hitWeapons, w)
                    end
                end
            end
        end
    end
    for _, w in ipairs(hitWeapons) do
        if valid(w) then
            local a = addr(w)
            local v = readNum(w, "Last Hit Power")
            if a and v then
                local prev = lastHitPower[a]
                if prev ~= nil and math.abs(v - prev) > 1e-3 and v > 0 then
                    safe("Hit snapshot", snapshotHit, w)
                end
                lastHitPower[a] = v
            end
        end
    end
end

---------------------------------------------------------------------------
-- DUMP
---------------------------------------------------------------------------
-- Lists every variable the game's Blueprint classes add to an object (stops at native
-- engine classes). Used to find the game's own weapon knobs, like the arm vars on Willie.
local function dumpBPProps(obj, label)
    log("--- Variables on " .. label .. " ---")
    local cls = nil
    pcall(function() cls = obj:GetClass() end)
    local depth, count = 0, 0
    while valid(cls) and depth < 8 do
        local cname = "?"
        pcall(function() cname = cls:GetFName():ToString() end)
        if not string.find(cname, "_C", -2, true) then break end  -- reached engine classes
        pcall(function()
            cls:ForEachProperty(function(prop)
                local pname = prop:GetFName():ToString()
                local ptype = "?"
                pcall(function() ptype = prop:GetClass():GetFName():ToString() end)
                local val
                local ok, v = pcall(function() return obj[pname] end)
                if not ok then
                    val = "(unreadable " .. ptype .. ")"
                elseif type(v) == "number" then
                    val = string.format("%.4g", v)
                elseif type(v) == "boolean" then
                    val = tostring(v)
                else
                    local n = nil
                    if ptype == "ObjectProperty" then
                        pcall(function() if valid(v) then n = nameOf(v) end end)
                    end
                    val = n and ("-> " .. n) or ("(" .. ptype .. ")")
                end
                log(string.format("  [%s] %s = %s", cname, pname, val))
                count = count + 1
            end)
        end)
        local nextCls = nil
        pcall(function() nextCls = cls:GetSuperStruct() end)
        cls = nextCls
        depth = depth + 1
    end
    log("  (" .. count .. " variables)")
end

local function dumpWeaponVars()
    local list = FindAllOf(Cfg.Weapons.ClassName) or {}
    local seen, n = {}, 0
    for _, actor in ipairs(list) do
        if valid(actor) and n < 3 then
            local cn = classNameOf(actor)
            if not seen[cn] and not isExcluded(nameOf(actor)) then
                seen[cn] = true
                n = n + 1
                local m = nil
                local body = weaponBody(actor)
                if body then m = massOf(body) end
                dumpBPProps(actor, nameOf(actor) .. (m and string.format(" (%.2f kg)", m) or ""))
            end
        end
    end
    if n == 0 then log("--- No weapons found for the variable dump ---") end
end

-- Lists the weapon Blueprint's functions whose names hint at mass/grip/build logic,
-- so we can see where the game applies "Mass Adjust Scale" and the part mass scales.
local function dumpWeaponFunctions()
    local actor = FindFirstOf(Cfg.Weapons.ClassName)
    if not valid(actor) then return end
    local words = { "mass", "weight", "grip", "generat", "build", "construct", "spawn",
                    "physic", "inertia", "balance", "setup", "init", "module", "custom", "attach" }
    log("--- Functions on weapon Blueprint (filtered) ---")
    local cls = nil
    pcall(function() cls = actor:GetClass() end)
    local depth, count = 0, 0
    while valid(cls) and depth < 8 do
        local cname = "?"
        pcall(function() cname = cls:GetFName():ToString() end)
        if not string.find(cname, "_C", -2, true) then break end
        local ok, err = pcall(function()
            cls:ForEachFunction(function(fn)
                local fname = fn:GetFName():ToString()
                local lower = string.lower(fname)
                for _, w in ipairs(words) do
                    if string.find(lower, w, 1, true) then
                        log(string.format("  [%s] %s", cname, fname))
                        count = count + 1
                        break
                    end
                end
            end)
        end)
        if not ok then log("  ForEachFunction failed: " .. tostring(err)) end
        local nextCls = nil
        pcall(function() nextCls = cls:GetSuperStruct() end)
        cls = nextCls
        depth = depth + 1
    end
    log("  (" .. count .. " matching functions)")
end

local function dump()
    local mins = math.max((os.time() - startTime) / 60, 1 / 60)
    log("================ STATUS v2 ================")
    log("Mod enabled: " .. tostring(enabled))
    local n = 0
    for _, st in pairs(pawns) do
        n = n + 1
        if valid(st.obj) and (st.isPlayer or n <= 4) then
            log((st.isPlayer and "PLAYER " or "NPC    ") .. st.name)
            if Cfg.Arms.Dynamic and Cfg.Arms.Dynamic.Enabled then
                log(string.format("  dynamic: hand speed now=%s cm/s, peak since last F9=%s, swing blend=%.2f (0=hold, 1=swing), two-handed=%s",
                    st.speed and string.format("%.0f", st.speed) or "?",
                    st.peakSpeed and string.format("%.0f", st.peakSpeed) or "?", st.swing or 0,
                    tostring(st.twoHanded)))
                log(string.format("  two-handed %.0f%% of the time since last F9",
                    100 * (st.twoHandTicks or 0) / math.max(1, st.ticks or 0)))
                st.peakSpeed, st.ticks, st.twoHandTicks = 0, 0, 0
            end
            for name, cfgMult in pairs(Cfg.Arms.Multipliers) do
                local s = st.vars[name]
                local cur = readNum(st.obj, name)
                local mult = (s and s.mult) or cfgMult
                if s then
                    log(string.format("  %-22s now=%-10.4g gameBase=%-10.4g x%.2f  game resets=%d (%.1f/min)",
                        name, cur or -1, s.base, mult, s.resets, s.resets / mins))
                elseif mult ~= 1.0 then
                    log(string.format("  %-22s NOT FOUND on this pawn", name))
                else
                    log(string.format("  %-22s now=%-10.4g (x1.0, untouched)", name, cur or -1))
                end
            end
            local watch = {}
            for _, wn in ipairs(Cfg.WatchVars or {}) do
                local ok, v = pcall(function() return st.obj[wn] end)
                if ok and type(v) == "number" then
                    table.insert(watch, string.format("%s=%.3g", wn, v))
                elseif ok and type(v) == "boolean" then
                    table.insert(watch, string.format("%s=%s", wn, tostring(v)))
                end
            end
            if #watch > 0 then log("  watch: " .. table.concat(watch, ", ")) end
        end
    end
    if n == 0 then log("No Willie_BP_C characters tracked (are you in a fight?)") end

    log("--- Weapons (" .. Cfg.Weapons.ClassName .. ", mass mode " ..
        (Cfg.Weapons.Enabled and ("ON x" .. tostring(Cfg.Weapons.MassScale)) or "OFF") .. ") ---")
    local wn = 0
    for _, w in pairs(weapons) do
        wn = wn + 1
        log(string.format("  %s  body=%s  status=%s  game resets=%d",
            w.name, w.compDesc or "?", w.status or "?", w.resets or 0))
        if w.baseMass then
            local live = w.comp and valid(w.comp)
            local m = live and massOf(w.comp) or nil
            local now = live and inertiaOf(w.comp) or nil
            local r = ratioOf(now, w.baseInertia)
            log(string.format("      mass %.2f -> %s kg (target x%.2f)  inertia %s -> %s  ratio=%s",
                w.baseMass, m and string.format("%.2f", m) or "?", Cfg.Weapons.MassScale or 1,
                vecStr(w.baseInertia), vecStr(now),
                r and string.format("%.2f/%.2f/%.2f", r.X, r.Y, r.Z) or "?"))
        end
    end
    if wn == 0 then log("  none found") end
    log("--- Weapon rebuild at spawn (" .. ((Cfg.Weapons.GameVarsEnabled ~= false and Cfg.Weapons.GameVars) and "ON" or "OFF") .. ") ---")
    local shown = 0
    for _, st in pairs(weaponVars) do
        if valid(st.obj) and shown < 10 then
            shown = shown + 1
            local mNow, iNow = bodyStats(st.obj)
            local held = nil
            pcall(function() held = st.obj["Is Held"] end)
            log(string.format("  %s  status=%s  held now=%s", st.name, st.status or "?", tostring(held)))
            if st.status == "rebuilt" then
                log(string.format("      held at rebuild=%s  mass %s -> %s (now %s) kg  inertia %s -> %s",
                    tostring(st.heldAtRebuild),
                    st.mass0 and string.format("%.2f", st.mass0) or "?",
                    st.mass1 and string.format("%.2f", st.mass1) or "?",
                    mNow and string.format("%.2f", mNow) or "?",
                    vecStr(st.inertia0), vecStr(iNow)))
            end
            for name, s in pairs(st.vars) do
                log(string.format("      %-28s now=%-8.4g was=%-8.4g  game resets=%d",
                    name, readNum(st.obj, name) or -1, s.base, s.resets or 0))
            end
        end
    end
    if shown == 0 then log("  none tracked") end
    if Cfg.DumpWeaponVars then safe("Weapon variable dump", dumpWeaponVars) end
    if Cfg.DumpWeaponFunctions ~= false then safe("Weapon function dump", dumpWeaponFunctions) end
    if Cfg.HitLog and Cfg.HitLog.Enabled then
        log(string.format("--- Your hits since last F9 (%d, newest last) ---", #hitLog))
        for _, h in ipairs(hitLog) do log("  " .. formatHit(h)) end
        if #hitLog == 0 then log("  none recorded (hold a weapon and hit something)") end
        hitLog = {}
    end
    log("================ END STATUS ================")
end

---------------------------------------------------------------------------
-- IN-GAME MESSAGE: a small text widget built at runtime (no game assets needed).
-- If UMG creation fails on this build, falls back to PrintString, then the log only.
---------------------------------------------------------------------------
local toast = { widget = nil, text = nil, token = 0 }

local function makeToastWidget(pc)
    local wbl = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    local uwClass = StaticFindObject("/Script/UMG.UserWidget")
    local treeClass = StaticFindObject("/Script/UMG.WidgetTree")
    local textClass = StaticFindObject("/Script/UMG.TextBlock")
    if not (valid(wbl) and valid(uwClass) and valid(treeClass) and valid(textClass)) then
        error("UMG classes not found")
    end
    local w = wbl:Create(pc, uwClass, pc)
    if not valid(w) then error("Create returned nothing") end
    local tree = StaticConstructObject(treeClass, w, FName("SP_WidgetTree"))
    w.WidgetTree = tree
    local t = StaticConstructObject(textClass, tree, FName("SP_ToastText"))
    tree.RootWidget = t
    pcall(function() t.Font.Size = 22 end)
    pcall(function() t:SetShadowOffset({ X = 2, Y = 2 }) end)
    pcall(function() t:SetShadowColorAndOpacity({ R = 0, G = 0, B = 0, A = 0.9 }) end)
    pcall(function() t:SetJustification(1) end)  -- center
    return w, t
end

local function showToast(msg, color)
    log(msg)
    if Cfg.ShowToast == false then return end
    local pc = FindFirstOf("PlayerController")
    local ok, err = pcall(function()
        if not valid(toast.widget) or not valid(toast.text) then
            toast.widget, toast.text = makeToastWidget(pc)
        end
        local w, t = toast.widget, toast.text
        t:SetText(FText(msg))
        pcall(function()
            t:SetColorAndOpacity({ SpecifiedColor = color, ColorUseRule = 0 })
        end)
        if not w:IsInViewport() then w:AddToViewport(9999) end
        pcall(function()
            w:SetAnchorsInViewport({ Minimum = { X = 0.5, Y = 0.1 }, Maximum = { X = 0.5, Y = 0.1 } })
            w:SetAlignmentInViewport({ X = 0.5, Y = 0.5 })
        end)
    end)
    if not ok then
        -- fallback: engine debug text (may be hidden in shipping builds)
        local ok2 = pcall(function()
            local ksl = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            ksl:PrintString(pc, msg, true, false, { R = color.R, G = color.G, B = color.B, A = 1 }, 2.5, FName("None"))
        end)
        if not toast.warned then
            toast.warned = true
            log("On-screen message failed (" .. tostring(err) .. ")" ..
                (ok2 and "; used PrintString instead" or "; only the log shows on/off"))
        end
        return
    end
    toast.token = toast.token + 1
    local my = toast.token
    ExecuteWithDelay(Cfg.ToastSeconds and math.floor(Cfg.ToastSeconds * 1000) or 2500, function()
        ExecuteInGameThread(function()
            if toast.token == my and valid(toast.widget) then
                pcall(function() toast.widget:RemoveFromParent() end)
            end
        end)
    end)
end

---------------------------------------------------------------------------
-- FULL ON/OFF
-- Off: restore every game variable we changed (arms, Grip Rate, weapon weight setting) and
--      rebuild the weapons we made heavier, so they go back to vanilla weight.
-- On:  forget weapon state, so every weapon (held ones too) gets the weight setting and a
--      rebuild again, and the arm/grip boosts come back on the next tick.
-- Rebuilding held weapons worked fine in testing (13 were held at rebuild, no problems seen).
---------------------------------------------------------------------------
local function turnOff()
    disableAll()  -- restores arm vars and weapon vars (Mass Adjust back to 1.0, Grip Rate)
    local n = 0
    for _, st in pairs(weaponVars) do
        if valid(st.obj) and (st.status == "rebuilt" or st.status == "waiting to rebuild") then
            local ok = pcall(function() local fn = st.obj[REBUILD_FN]; fn(st.obj) end)
            if ok then n = n + 1 end
            st.status, st.rebuildAt, st.checkAt = "restored to vanilla", nil, nil
        end
    end
    return n
end

local function turnOn()
    weaponVars = {}
    weaponFirstScan = false  -- treat every existing weapon as new: boost + rebuild
end

RegisterKeyBind(Cfg.Keys.Toggle, function()
    ExecuteInGameThread(function()
        enabled = not enabled
        if enabled then
            safe("Enable", turnOn)
            showToast("WeaponsHandling+ ON", { R = 0.4, G = 1.0, B = 0.4, A = 1 })
        else
            local ok, n = pcall(turnOff)
            if not ok then log("Disable failed: " .. tostring(n)) end
            showToast("WeaponsHandling+ OFF (vanilla)", { R = 1.0, G = 0.45, B = 0.35, A = 1 })
            if ok then log("Restored " .. tostring(n) .. " weapons to vanilla weight") end
        end
    end)
end)

RegisterKeyBind(Cfg.Keys.Apply, function()
    ExecuteInGameThread(function()
        safe("Reset", forgetAll)
        if enabled then
            safe("Arms", applyArms)
            safe("Weapons", applyWeapons)
            safe("Weapon vars", applyWeaponVars)
        end
        log("Re-applied.")
    end)
end)

RegisterKeyBind(Cfg.Keys.Dump, function()
    ExecuteInGameThread(function() safe("Dump", dump) end)
end)

local tick = 0
local weaponEvery = math.max(1, math.floor(Cfg.WeaponIntervalMs / Cfg.ArmIntervalMs))
LoopAsync(Cfg.ArmIntervalMs, function()
    ExecuteInGameThread(function()
        safe("Hit recorder", trackHits)  -- runs with the mod on or off
        if not enabled then return end
        safe("Arms", applyArms)
        safe("Weapon rebuild", applyWeaponVars)  -- every tick: catch new weapons at spawn
        tick = tick + 1
        if tick % weaponEvery == 0 then
            safe("Weapons", applyWeapons)
        end
    end)
    return false
end)

log("v1.0.0 loaded. F7 = on/off, F8 = re-apply, F9 = status to UE4SS.log")
